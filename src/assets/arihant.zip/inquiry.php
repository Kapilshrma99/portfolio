<?php 
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';


$name=isset($_POST['name'])?$_POST['name']:''; 
$email=isset($_POST['email'])?$_POST['email']:'';
 $phone=isset($_POST['phone'])?$_POST['phone']:'';  
$message=isset($_POST['message'])?$_POST['message']:'';


if(!empty($phone) && !empty($name) )
{ 
$to = "arihantairambulance4@gmail.com";
// $to = "designer.adkeymedia@gmail.com";
$subject = "Enquiry From  " . $name . "https://www.arihantairambulance.com/";
$txt='Hi Enquiry From https://www.arihantairambulance.com/<br /><br />'.ucfirst($name ).' has sent you a message via contact form on your website! <br /><br />
Name: '.ucfirst($name ).'<br />
Phone: '.ucfirst( $phone ).'<br />
Email: '.ucfirst( $email ).'<br />
Message: '.ucfirst( $message ).'<br />';

 

$mail = new PHPMailer;
    // Server settings
    // $mail->SMTPDebug = 2;                      // Enable verbose debug output
    $mail->isSMTP();                                            // Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
    $mail->Username   = 'enquiryadkeymedia@gmail.com';                     // SMTP username
    $mail->Password   = 'omptrrvxyzttovot';                               // SMTP password
    $mail->SMTPSecure = 'tls';         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
    $mail->Port       = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above

    // Recipients
    $mail->setFrom('enquiryadkeymedia@gmail.com', 'Enquiry');
    // $mail->addAddress('joe@example.net', 'Joe User');     // Add a recipient
    $mail->addAddress($to);
    $mail->addAddress('');// Name is optional
     
;
    
    // Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject =  $subject;
    $mail->Body    =   $txt;
    $mail->AltBody =  $txt;

  if($mail->send()){
  $servername = "localhost";
$username = "instagyan_query2";
$password = "V#ve3B!vQ2uz";
$dbname = "instagyan_query1";






echo "<script>window.location.href='thanks.html';</script>";
 exit;

} else {
  printf ("<b>errormessage</b>");
}

}

?>
